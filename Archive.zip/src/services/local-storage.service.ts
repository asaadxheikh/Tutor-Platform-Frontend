export const LocalStorage = {
  getItem: (key: string) => {
    return localStorage.getItem(`${key}`);
  },

  setItem: (key: string, value: string) => {
    localStorage.setItem(`${key}`, `${value}`);
  },

  removeItem: (key: string) => {
    localStorage.removeItem(`${key}`);
  },

  doesExists: (key: string): boolean => {
    return localStorage.getItem(`${key}`) ? true : false;
  },
};
