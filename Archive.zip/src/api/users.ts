import axiosHttp from "../services/axios.service";
import {
  IUserSignUpRequest,
  IUserSignUpResponse,
  ILoginRequest,
  ILoginResponse,
  IForgotPasswordResponse,
  IChangePasswordRequest,
  IGeneralRequestResponse,
} from "../types/context/auth";

export const signupUser = async (user: IUserSignUpRequest) => {
  delete user["cpassword"];
  const response = await axiosHttp.post<IUserSignUpResponse>(
    `/v1/api/users`,
    user
  );

  return response.data;
};

export const loginUser = async (request: ILoginRequest) => {
  const response = await axiosHttp.post<ILoginResponse>(
    `/v1/api/users/login`,
    request
  );

  return response.data;
};

export const fetchUserInformation = async (id?: string) => {
  const url = id ? `/v1/api/users/${id}` : `/v1/api/users`;
  const response = await axiosHttp.get<ILoginResponse>(`${url}`);
  return response.data;
};

export const forgotPassword = async (email: string) => {
  const response = await axiosHttp.post<IForgotPasswordResponse>(
    `/v1/api/users/forgot-password`,
    {
      email,
    }
  );
  return response.data;
};

export const resetPassword = async (request: IChangePasswordRequest) => {
  const { verification_link, password } = request;
  const response = await axiosHttp.post<IForgotPasswordResponse>(
    `/v1/api/users/reset-password`,
    {
      verification_link,
      password,
    }
  );
  return response.data;
};

export const verifyEmail = async (id: string) => {
  const response = await axiosHttp.get<IGeneralRequestResponse>(
    `/v1/api/users/Verification/${id}`
  );
  return response.data;
};
