/**
 * Basic user information
 */
export interface IUserInfo {
  first_name: string;
  last_name: string;
  email: string;
}

export interface IUserPassword {
  password: string;
  cpassword?: string;
}

export interface IUserFormState extends IUserPassword, IUserInfo {}

/**
 * Sign up request interface
 */
export interface IUserSignUpRequest extends IUserInfo, IUserPassword {
  user_type: string;
}

/**
 * Sign up request response against user
 */
interface IUserSignUpResponseInfo extends IUserInfo {
  created_at: string;
  updated_at: string;
  _id: string;
  verification_link: string;
  email_verified: boolean;
}

/**
 * Sign up response with user information
 */
export interface IUserSignUpResponse {
  status: string;
  message: string;
  data: IUserSignUpResponseInfo;
}

/**
 * Login request
 */
export interface ILoginRequest {
  email: string;
  password: string;
  remember_me?: boolean;
}

/**
 * Login request with token and user information
 */
export interface ILoginResponsInfo extends IUserInfo {
  token: string;
  _id: string;
  email_verified?: boolean;
}

/**
 * Login request with token and status
 */
export interface ILoginResponse {
  status: string;
  message: string;
  data: ILoginResponsInfo;
}

export interface IForgotPasswordResponse {
  status: string;
  message: string;
  data?: any; // don't know what backend dev want to do with this key
}

export interface IGeneralRequestResponse {
  status: string;
  message: string;
  data?: any; // don't know what backend dev want to do with this key
}

export interface IChangePasswordRequest {
  verification_link: string;
  password: string;
}
