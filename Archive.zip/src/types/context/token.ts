export interface IToken {
  /* create interface for token */
}
