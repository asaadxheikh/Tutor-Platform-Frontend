import { actionTypes } from "../stores/users";

export interface IUser {
  id: number;
  name: string;
  username: string;
  email: string;
}

export interface FetchUsersSuccessPayload {
  users: IUser[];
}
export interface ILocation {}
