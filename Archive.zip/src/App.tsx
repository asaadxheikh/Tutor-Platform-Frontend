import React from "react";
import { BrowserRouter as Router, Routes } from "react-router-dom";
import RouterView from "./components/routes/RouteView";

const AppWrapper = () => {
  return (
    <Router>
      <RouterView />
    </Router>
  );
};

export default AppWrapper;
