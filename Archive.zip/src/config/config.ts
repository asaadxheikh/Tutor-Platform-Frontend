export const ENV = `${process.env.NODE_ENV || "production"}`;
export const IS_PROD = ENV === "production";

export const HOST_URL =
  process.env.HOST_URL ??
  (IS_PROD
    ? `${process.env.REACT_APP_PRODUCTION_URL}`
    : `${process.env.REACT_APP_LOCAL_URL}`);
