import { combineReducers } from "redux";
import {
  TypedUseSelectorHook,
  useSelector as useSelectorNative,
  useDispatch as useDispatchNative,
} from "react-redux";
import {
  reducer as UserReducer,
  Actions as UserActions,
  initialState as usersInitialState,
} from "./users/index";
import {
  reducer as alertReducer,
  initialState as alertInitialState,
  Actions as AlertActions,
} from "./alert";
import { Dispatch } from "react";

/* group all app reducers */
export const rootReducer = combineReducers({
  users: UserReducer,
  alert: alertReducer,
});

/* group all app initialState */

export const rootInitialState = {
  users: usersInitialState,
  alert: alertInitialState,
};

/* group all app actions */
export type RootActions = UserActions | AlertActions;

/* export useSelector hook */

export const useSelector: TypedUseSelectorHook<typeof rootInitialState> =
  useSelectorNative;

/* export useDispatch hook */
export const useDispatch = () => useDispatchNative<Dispatch<RootActions>>();
