import { createStore, applyMiddleware } from "redux";
import createSagaMiddleware from "@redux-saga/core";
import { rootReducer } from "./rootReducer";
import { composeWithDevTools } from "redux-devtools-extension";

/* create saga middleware */
import { rootSaga } from "../sagas";
const sagaMiddleware = createSagaMiddleware();

/* mount it into the store */

const configureStore = () => {
  const store = createStore(
    rootReducer,
    composeWithDevTools(
      applyMiddleware(sagaMiddleware)
      // other store enhancers if any
    )
  );
  sagaMiddleware.run(rootSaga);
  return store;
};

export default configureStore;
