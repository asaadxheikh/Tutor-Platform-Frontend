import {
  IChangePasswordRequest,
  IForgotPasswordResponse,
  ILoginRequest,
  ILoginResponse,
  ILoginResponsInfo,
  IUserSignUpRequest,
  IUserSignUpResponse,
} from "../../types/context/auth";

export const actionTypes = {
  FETCH_USERS: "@@USER/FETCH_USERS",
  FETCH_USERS_SUCCESS: "@@USER/FETCH_USERS_SUCCESS",
  REGISTER_USER: "@@USER/REGISTER_USER",
  REGISTER_USER_SUCCESS: "@@USER/REGISTER_USER_SUCCESS",
  LOGIN_USER: "@@USER/LOGIN_USER",
  LOGIN_USER_SUCCESS: "@@USER/LOGIN_USER_SUCCESS",
  GET_USER: "@@USER/GET_USER",
  GET_USER_SUCCESS: "@@USER/GET_USER_SUCCESS",
  FORGOT_PASSWORD: "@@USER/FORGOT_PASSWORD",
  FORGOT_PASSWORD_SUCCESS: "@@USER/FORGOT_PASSWORD_SUCCESS",
  CHANGE_PASSWORD: "@@USER/CHANGE_PASSWORD",
  CHANGE_PASSWORD_SUCCESS: "@@USER/CHANGE_PASSWORD_SUCCESS",
  LOGOUT_USER: "@@USER/LOGOUT_USER",
} as const;

export const doRegisterUser = (request: IUserSignUpRequest) => ({
  type: actionTypes.REGISTER_USER,
  request,
});

export const doRegisterUserSuccess = (response: IUserSignUpResponse) => ({
  type: actionTypes.REGISTER_USER_SUCCESS,
  response,
});
export const doLoginUser = (request: ILoginRequest) => ({
  type: actionTypes.LOGIN_USER,
  request,
});

export const doLoginUserSuccess = (response: ILoginResponsInfo) => ({
  type: actionTypes.LOGIN_USER_SUCCESS,
  response,
});

export const doFetchUser = (id?: string) => ({
  type: actionTypes.GET_USER,
  id,
});
export const doFetchUserSuccess = (response: ILoginResponsInfo) => ({
  type: actionTypes.GET_USER_SUCCESS,
  response,
});

export const doForgotPassword = (email: string) => ({
  type: actionTypes.FORGOT_PASSWORD,
  email,
});
export const doForgotPasswordSuccess = (response: IForgotPasswordResponse) => ({
  type: actionTypes.FORGOT_PASSWORD_SUCCESS,
  response,
});
export const doChangePassowrd = (request: IChangePasswordRequest) => ({
  type: actionTypes.CHANGE_PASSWORD,
  request,
});

export const doChangePassowrdSuccess = (response: IForgotPasswordResponse) => ({
  type: actionTypes.CHANGE_PASSWORD_SUCCESS,
  response,
});
export const doLogoutUser = () => ({
  type: actionTypes.LOGOUT_USER,
});

export type Actions =
  | ReturnType<typeof doRegisterUser>
  | ReturnType<typeof doRegisterUserSuccess>
  | ReturnType<typeof doLoginUser>
  | ReturnType<typeof doLoginUserSuccess>
  | ReturnType<typeof doFetchUser>
  | ReturnType<typeof doFetchUserSuccess>
  | ReturnType<typeof doForgotPassword>
  | ReturnType<typeof doForgotPasswordSuccess>
  | ReturnType<typeof doChangePassowrd>
  | ReturnType<typeof doChangePassowrdSuccess>
  | ReturnType<typeof doLogoutUser>;
