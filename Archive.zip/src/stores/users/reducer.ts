import { Actions } from "./actions";
import { rootInitialState } from "../rootReducer";
import { actionTypes } from ".";
import {
  IForgotPasswordResponse,
  ILoginResponsInfo,
} from "../../types/context/auth";
/* create the user store */
export interface IUserStore {
  user: ILoginResponsInfo | null;
  loading: boolean;
  forgotPassword?: IForgotPasswordResponse;
  resetPassword?: IForgotPasswordResponse;
  forgotPasswordRequestSending: boolean;
}

/* create default state */
const defaultState = {
  loading: false,
  user: null,
  forgotPasswordRequestSending: false,
};

/* set the initial state */
export const initialState: IUserStore = defaultState;

/**
 * initalState
 */

export interface IHydrateAction {
  payload: typeof rootInitialState;
}

export const reducer = (state: IUserStore = initialState, action: Actions) => {
  switch (action.type) {
    case actionTypes.GET_USER:
    case actionTypes.LOGIN_USER:
    case actionTypes.REGISTER_USER:
    case actionTypes.CHANGE_PASSWORD:
      return {
        ...state,
      };

    case actionTypes.LOGIN_USER_SUCCESS:
    case actionTypes.REGISTER_USER_SUCCESS:
    case actionTypes.GET_USER_SUCCESS:
      return {
        ...state,
        user: action.response,
      };
    case actionTypes.FORGOT_PASSWORD_SUCCESS:
      return {
        ...state,
        forgotPassword: action.response,
        forgotPasswordRequestSending: false,
      };
    case actionTypes.FORGOT_PASSWORD:
      return {
        ...state,
        forgotPasswordRequestSending: true,
      };

    case actionTypes.CHANGE_PASSWORD_SUCCESS:
      return {
        ...state,
        resetPassword: action.response,
      };

    case actionTypes.LOGOUT_USER:
      return {
        ...state,
        user: null,
      };
    default:
      return state;
  }
};
