import { IUserStore } from ".";

export interface IRootStore {
  users: IUserStore;
}

export const currentUserInfo = (store: IRootStore) => store.users.user;
export const isForgotPasswordRequestSent = (store: IRootStore) =>
  store.users.forgotPasswordRequestSending;
export const FetchForgotPasswordResponse = (store: IRootStore) =>
  store.users.forgotPassword;

export const FetchResetPasswordResponse = (store: IRootStore) =>
  store.users.resetPassword;
