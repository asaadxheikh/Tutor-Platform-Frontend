import { IFormValidation } from "../../types/alert";
import {
  IUserFormState,
  ILoginRequest,
  IUserPassword,
} from "../../types/context/auth";
import { validationError } from "./errors";

/**
 * Validate the signup form
 * @param user
 * @returns
 */
export const validateSignUpForm = (user: IUserFormState): IFormValidation => {
  const { password, cpassword } = user;
  if (
    !user.first_name ||
    !user.last_name ||
    !user.password ||
    !user.cpassword ||
    !user.email
  ) {
    return {
      error: true,
      message: validationError("all.fields.required"),
    };
  }

  if (password?.toLowerCase() !== cpassword?.toLowerCase()) {
    return {
      error: true,
      message: validationError("passwords.matched"),
    };
  }

  /* Todo: Add email verification */
  return {
    error: false,
    message: "",
  };
};

/**
 * Validate the login form
 * @param user
 * @returns
 */
export const validateLoginForm = (user: ILoginRequest): IFormValidation => {
  const { password, email } = user;
  if (!password || !email) {
    return {
      error: true,
      message: validationError("all.fields.required"),
    };
  }

  return {
    error: false,
    message: "",
  };
};

/**
 * Validate the change password form
 * @param user
 * @returns
 */
export const validateChangePasswordForm = (
  user: IUserPassword
): IFormValidation => {
  const { password, cpassword } = user;
  if (!password || !cpassword) {
    return {
      error: true,
      message: validationError("all.fields.required"),
    };
  }

  if (password.toLowerCase() !== cpassword.toLowerCase()) {
    return {
      error: true,
      message: validationError("passwords.matched"),
    };
  }

  return {
    error: false,
    message: "",
  };
};
