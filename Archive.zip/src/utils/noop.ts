export const noop = () => {
  /* non operational function */
};
