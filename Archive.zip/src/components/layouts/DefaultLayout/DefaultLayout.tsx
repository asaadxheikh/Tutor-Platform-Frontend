import React, { FC, Fragment } from "react";
import { Footer } from "../Footer/Footer";
import { Header } from "../Header/Header";

interface IDefaultLayoutProps {
  theme?: boolean;
}
export const DefaultLayout: FC<IDefaultLayoutProps> = ({ children }) => {
  return (
    <Fragment>
      <Header></Header>
      <Fragment>{children}</Fragment>
      <Footer></Footer>
    </Fragment>
  );
};
