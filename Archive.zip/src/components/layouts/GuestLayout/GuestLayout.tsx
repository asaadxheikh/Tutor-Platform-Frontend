import React, { FC, Fragment } from "react";
import { Navigate, Outlet, useNavigate } from "react-router-dom";
import { DefaultLayout } from "../DefaultLayout/DefaultLayout";

export const GuestLayout: FC = ({ children }) => {
  return (
    <DefaultLayout>
      <Fragment>{children}</Fragment>

      <Outlet />
    </DefaultLayout>
  );
};
