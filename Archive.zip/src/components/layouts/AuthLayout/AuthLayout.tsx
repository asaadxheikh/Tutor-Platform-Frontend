import React, { FC, Fragment } from "react";
import { Navigate, Outlet } from "react-router-dom";
import { DefaultLayout } from "../DefaultLayout/DefaultLayout";

export const AuthLayout: FC = ({ children }) => {
  return (
    <DefaultLayout>
      <Fragment>{children}</Fragment>
      <Outlet />
    </DefaultLayout>
  );
};
