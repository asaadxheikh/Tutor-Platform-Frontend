import React from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../../hooks/useAuth";
import { removeLocalStorageToken } from "../../../services/token.service";
import { useDispatch } from "../../../stores/rootReducer";
import { doLogoutUser } from "../../../stores/users";
import { createModuleStyleExtractor } from "../../../utils/css";
import styles from "./Header.module.scss";
const cx = createModuleStyleExtractor(styles);
export const Header = () => {
  const { token } = useAuth();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const onButtonClick = () => {
    dispatch(doLogoutUser());
    token && removeLocalStorageToken();

    navigate("/auth", { replace: true });
  };
  return (
    <>
      <div className={cx("layout-header")}>
        {/* header will goes here */}
        <nav className="navbar navbar-expand-sm navbar-light py-3 container">
          <a className="navbar-brand" href="#">
            <img src="/assets/images/logo.png" width="100px" alt="" />
          </a>
          <button
            className="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#navbarNavDropdown"
            aria-controls="navbarNavDropdown"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNavDropdown">
            <ul className="navbar-nav ml-auto">
              <li className="nav-item">
                <button onClick={onButtonClick} className="btn px-4 py-2">
                  <i className="fa fa-user"></i>{" "}
                  {token ? "Logout" : "Login/Register"}
                </button>
              </li>
            </ul>
          </div>
        </nav>
      </div>
    </>
  );
};
