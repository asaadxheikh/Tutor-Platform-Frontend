import React, { ComponentType } from "react";
import { RouteProps, Navigate } from "react-router-dom";
import { useAuth } from "../../hooks/useAuth";
export type ProtectedRouteProps = {
  role?: string;
  authenticationPath?: string;
  Component: ComponentType;
} & RouteProps;

export default function ProtectedRoute<T>({
  role,
  authenticationPath,
  Component,
  ...routeProps
}: ProtectedRouteProps): JSX.Element {
  const { token } = useAuth();
  return token ? <Component {...routeProps} /> : <Navigate to={"/auth"} />;
}
