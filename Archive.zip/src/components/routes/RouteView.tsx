import React from "react";
import { useRoutes, Navigate } from "react-router-dom";
import { useAuth } from "../../hooks/useAuth";
import { AuthLayout } from "../layouts/AuthLayout/AuthLayout";
import { GuestLayout } from "../layouts/GuestLayout/GuestLayout";
import { AuthPage } from "../organisms/Auth/Auth";
import { ChangePassword } from "../organisms/ChangePassword/ChangePassword";
import { HomePage } from "../organisms/Home/Home";

import { ResetPasword } from "../organisms/ResetPassword/ResetPassword";
import { VerifyEmail } from "../organisms/VerifyEmail/VerifyEmail";

const PageNotFoundView = () => {
  //Todo: We will create our own 404 Page in
  return (
    <div style={{ textAlign: "center" }}>
      <h1>404</h1>
    </div>
  );
};

const RouterView = () => {
  const { token } = useAuth();
  const guestRoutes = {
    path: "auth",
    exact: true,
    element: !token ? <GuestLayout /> : <Navigate to={"/"} />,
    children: [
      { exact: true, path: "*", element: <PageNotFoundView /> },
      { exact: true, path: "404", element: <PageNotFoundView /> },
      { exact: true, path: "forgot-password", element: <ResetPasword /> },
      { exact: true, path: "reset-password/:id", element: <ChangePassword /> },
      { exact: true, path: "verify-identity/:id", element: <VerifyEmail /> },
      {
        exact: true,
        path: "",
        element: <AuthPage />,
      },
    ],
  };

  const authRoutes = {
    path: "",
    element: token ? <AuthLayout /> : <Navigate to="/auth" />,
    children: [
      { exact: true, path: "*", element: <Navigate to="/404" /> },

      {
        exact: true,
        path: "",
        element: <HomePage />,
      },
    ],
  };
  const routes = useRoutes([authRoutes, guestRoutes]);
  return <>{routes}</>;
};
export default RouterView;
