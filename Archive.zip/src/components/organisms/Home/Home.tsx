import React from "react";
import { useFetchUser } from "../../../hooks/useFetchUser";

export const HomePage = () => {
  const user = useFetchUser();

  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      {user && <h1> Welcome {user.user.first_name} Page MVP Coming Soon </h1>}
    </div>
  );
};
