import React, { FC, useState } from "react";
import { useDispatch } from "../../../stores/rootReducer";
import { doRegisterUser } from "../../../stores/users";
import { IAlert } from "../../../types/alert";
import {
  IUserFormState,
  IUserSignUpRequest,
} from "../../../types/context/auth";
import { noop } from "../../../utils/noop";
import { validateSignUpForm } from "../../../utils/validation/validations";

interface ISignup {
  onNotification: (alert: IAlert) => void;
  enableNotification?: boolean;
}
const Signup: FC<ISignup> = ({ onNotification = noop, enableNotification }) => {
  const dispatch = useDispatch();
  const defaultState = {
    first_name: "",
    last_name: "",
    email: "",
    password: "",
    cpassword: "",
  };
  const [user, setUser] = useState<IUserFormState>(defaultState);

  const updateState = (key: string, value: string) => {
    setUser({
      ...user,
      [key]: value,
    });
  };
  const onSubmit = async (
    event: React.MouseEvent<HTMLButtonElement, MouseEvent>
  ) => {
    event.preventDefault();

    const { error, message } = validateSignUpForm(user);
    if (error) {
      return onNotification({
        type: "DANGER",
        message,
        active: true,
      });
    }

    const signUpRequest: IUserSignUpRequest = {
      ...user,
      user_type: "Student",
    };
    dispatch(doRegisterUser(signUpRequest));
    setUser(defaultState);
  };

  const { first_name, last_name, email, password, cpassword } = user;
  return (
    <div className="col-md-6 mt-5 mt-md-0">
      <div className="col-12 p-5 register">
        <h2 className="mb-4">Register</h2>
        <form>
          <div className="form-group">
            <label htmlFor="fname">First Name</label>
            <input
              type="text"
              className="form-control name"
              id="fname"
              placeholder="First Name"
              value={first_name}
              onChange={(event) =>
                updateState("first_name", event.target.value)
              }
            />
          </div>
          <div className="form-group">
            <label htmlFor="lname">Last Name</label>
            <input
              type="text"
              className="form-control name"
              id="lname"
              placeholder="Last Name"
              value={last_name}
              onChange={(event) => updateState("last_name", event.target.value)}
            />
          </div>
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              className="form-control email"
              id="email"
              placeholder="Email"
              value={email}
              onChange={(event) => updateState("email", event.target.value)}
            />
          </div>
          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              className="form-control password"
              id="password"
              placeholder="Password"
              value={password}
              onChange={(event) => updateState("password", event.target.value)}
            />
          </div>
          <div className="form-group">
            <label htmlFor="cpassword">Confirm Password</label>
            <input
              type="password"
              className="form-control password"
              id="cpassword"
              placeholder="Confirm Password"
              value={cpassword}
              onChange={(event) => updateState("cpassword", event.target.value)}
            />
          </div>
          <small className="form-text text-muted my-3">
            The password should be at least eight characters long. To make it
            stronger, use upper and lower case letters, numbers, and symbols
            like {'! " ? $ % ^'} )
          </small>

          <button type="submit" className="btn" onClick={onSubmit}>
            Register
          </button>
        </form>
      </div>
    </div>
  );
};
export default Signup;
