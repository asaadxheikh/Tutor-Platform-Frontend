import React, { useEffect } from "react";
import { currentAlertState } from "../../../stores/alert/selectors";
import { useDispatch, useSelector } from "../../../stores/rootReducer";
import { doForgotPassword } from "../../../stores/users";
import {
  FetchForgotPasswordResponse,
  isForgotPasswordRequestSent,
} from "../../../stores/users/selectors";
import { validateEmail } from "../../../utils/common";
import Alert from "../../atoms/Alert/Alert";

export const ResetPasword = () => {
  const [email, setEmail] = React.useState<string>("");
  const [error, setError] = React.useState<string>("");
  const [submitted, setSubmitted] = React.useState<boolean>(false);
  const alert = useSelector(currentAlertState);
  const dispatch = useDispatch();

  const resetPasswordRequest = useSelector(FetchForgotPasswordResponse);
  const isRequestInQueue: boolean = useSelector((store) =>
    isForgotPasswordRequestSent(store)
  );

  const onFormSubmit = React.useCallback(
    (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      if (email.length === 0) {
        setError("Email is required");
        return;
      }
      if (!validateEmail(email)) {
        setError("Please enter valid email");
        return;
      }

      setSubmitted(true);
      dispatch(doForgotPassword(email));
    },
    [email]
  );

  useEffect(() => {
    resetPasswordRequest?.status !== "FAILURE" && setEmail("");
  }, [resetPasswordRequest]);
  return (
    <>
      <div className="header">
        <div className="container">
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item active">
                {/* <Link to="/">Home</Link> */}
                <a href="#">Home</a>
              </li>
              <li className="breadcrumb-item active" aria-current="page">
                Reset Password
              </li>
            </ol>
          </nav>
          <h2 className="text-center mt-5">Reset Password</h2>
        </div>
      </div>
      <div className="container my-5">
        <div className="row">
          <div className="col-md-12">
            <div className={`${"col-12 p-5 card"}`}>
              <h2 className="mb-4">Reset Password</h2>

              <form onSubmit={onFormSubmit}>
                <div className="form-group">
                  <label htmlFor="email">Email {email} </label>
                  <input
                    type="email"
                    className="form-control email"
                    id="email"
                    placeholder="Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                  {error && error.length > 0 && (
                    <p className="text-danger form-text">{error}</p>
                  )}
                </div>
                <button type="submit" className="btn">
                  Submit
                </button>
              </form>
            </div>
            <div>
              {submitted &&
                (isRequestInQueue
                  ? "Request Sending"
                  : alert.active && (
                      <Alert message={alert.message} type={alert.type} />
                    ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
