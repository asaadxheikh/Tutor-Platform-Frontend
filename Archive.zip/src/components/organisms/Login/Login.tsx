import React, { FC, useState } from "react";
import { Link } from "react-router-dom";
import { useDispatch } from "../../../stores/rootReducer";
import { doLoginUser } from "../../../stores/users";
import { IAlert } from "../../../types/alert";
import { ILoginRequest } from "../../../types/context/auth";
import { noop } from "../../../utils/noop";
import { validateLoginForm } from "../../../utils/validation/validations";
export interface ILogin {
  onNotification: (alert: IAlert) => void;
  enableNotification?: boolean;
}
export const Login: FC<ILogin> = ({
  onNotification = noop,
  enableNotification,
}) => {
  const dispatch = useDispatch();
  const [user, updateUser] = useState<ILoginRequest>({
    email: "",
    password: "",
    remember_me: false,
  });

  const { email, password, remember_me } = user;

  const onSubmit = async (
    event: React.MouseEvent<HTMLButtonElement, MouseEvent>
  ) => {
    event.preventDefault();
    const { error, message } = validateLoginForm(user);
    if (error) {
      return onNotification({
        type: "DANGER",
        message,
        active: true,
      });
    }

    dispatch(doLoginUser(user));
  };
  return (
    <div className="col-md-6">
      <div className={`${"col-12 p-5 login"}`}>
        <h2 className="mb-4">Login</h2>
        <form>
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              className="form-control email"
              id="email"
              value={email}
              onChange={(event) =>
                updateUser({
                  ...user,
                  email: event.target.value,
                })
              }
              placeholder="Email"
            />
          </div>
          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              className="form-control password"
              id="password"
              value={password}
              onChange={(event) =>
                updateUser({
                  ...user,
                  password: event.target.value,
                })
              }
              placeholder="Password"
            />
          </div>
          <div className="form-row">
            <div className="col">
              <div className="form-group form-check">
                <input
                  checked={remember_me}
                  type="checkbox"
                  className="form-check-input"
                  id="remember"
                  onChange={() =>
                    updateUser({ ...user, remember_me: !remember_me })
                  }
                />
                <label
                  className="form-check-label text-muted"
                  htmlFor="remember"
                >
                  Remember Me
                </label>
              </div>
            </div>
            <div className="col text-right">
              <Link to={"/auth/forgot-password"} className="lost">
                {" "}
                Lost your password?
              </Link>
            </div>
          </div>
          <button type="button" className="btn" onClick={onSubmit}>
            Login
          </button>
        </form>
      </div>
    </div>
  );
};
