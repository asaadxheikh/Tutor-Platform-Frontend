import React from "react";
import { Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "../../../hooks/useAuth";
import { currentAlertState } from "../../../stores/alert/selectors";
import { useSelector } from "../../../stores/rootReducer";
import Alert from "../../atoms/Alert/Alert";
import { withNotification } from "../../hoc/withAlertNotification";
import { Login } from "../Login/Login";
import Signup from "../Signup/Signup";

const SignupWithNotification = withNotification(Signup);
const LoginWithNotification = withNotification(Login);
export const AuthPage = () => {
  const auth = useAuth();
  const naviate = useNavigate();
  if (auth) {
    naviate("/", { replace: true });
  }
  const alert = useSelector(currentAlertState); // extract the alert state
  return (
    <>
      <div className="header">
        <div className="container">
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <a href="#">Home</a>
              </li>
              <li className="breadcrumb-item active" aria-current="page">
                Authentication
              </li>
            </ol>
          </nav>
          <h2 className="text-center mt-5">Authentication</h2>
        </div>
      </div>

      <div className="container my-5">
        <div className="row">
          {alert.active && <Alert type={alert.type} message={alert.message} />}
          <LoginWithNotification enableNotification={false} />
          <SignupWithNotification enableNotification={false} />
        </div>
      </div>
    </>
  );
};
