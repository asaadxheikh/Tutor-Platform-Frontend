import { watchUserSagas } from "./users";
import { all } from "redux-saga/effects";
import { watchAlertSagas } from "./alert";
export function* rootSaga() {
  yield all([watchUserSagas(), watchAlertSagas()]);
}
