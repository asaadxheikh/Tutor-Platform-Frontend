import { put, takeEvery } from "@redux-saga/core/effects";
import { AxiosError } from "axios";
import { call } from "redux-saga/effects";
import {
  fetchUserInformation,
  forgotPassword,
  loginUser,
  resetPassword,
  signupUser,
} from "../api/users";
import { doCreateAlert } from "../stores/alert";
import {
  actionTypes,
  doChangePassowrd,
  doChangePassowrdSuccess,
  doFetchUser,
  doFetchUserSuccess,
  doForgotPassword,
  doForgotPasswordSuccess,
  doLoginUser,
  doLoginUserSuccess,
  doRegisterUser,
} from "../stores/users";
import { InferAsyncResponse } from "../types/asyncResponse";
import { ILoginResponsInfo } from "../types/context/auth";

import { noop } from "../utils/noop";

function* workLoadCreateUser(action: ReturnType<typeof doRegisterUser>) {
  try {
    const response: InferAsyncResponse<ReturnType<typeof signupUser>> =
      yield call(signupUser, action.request);
    const { email, password } = action.request;
    if (response) {
      if (response?.status === "FAILURE") {
        yield put(
          doCreateAlert({
            active: true,
            message: response.message,
            type: "DANGER",
          })
        );
      } else {
        yield put(doLoginUser({ email, password }));
      }
    }
  } catch (error) {
    () => noop;
  }
}

function* workLoadLoginUser(action: ReturnType<typeof doLoginUser>) {
  try {
    const response: InferAsyncResponse<ReturnType<typeof loginUser>> =
      yield call(loginUser, action.request);

    if (response) {
      if (response?.status === "FAILURE") {
        yield put(
          doCreateAlert({
            active: true,
            message: response.message,
            type: "DANGER",
          })
        );
      } else {
        const loginResponse: ILoginResponsInfo = {
          ...response.data,
        };
        yield put(doLoginUserSuccess(loginResponse));
      }
    }
  } catch (error) {
    const err = error as AxiosError;
    console.log(err.response?.data);
  }
}

function* workLoadFetchUser(action: ReturnType<typeof doFetchUser>) {
  try {
    console.log("inside saga");
    const response: InferAsyncResponse<
      ReturnType<typeof fetchUserInformation>
    > = yield call(fetchUserInformation, action.id);
    if (response) {
      if (response?.status === "FAILURE") {
        yield put(
          doCreateAlert({
            active: true,
            message: response.message,
            type: "DANGER",
          })
        );
      } else {
        const loginResponse: ILoginResponsInfo = {
          ...response.data,
        };
        yield put(doFetchUserSuccess(loginResponse));
      }
    }
  } catch (error) {
    () => noop;
  }
}

function* workLoadForgotPassword(action: ReturnType<typeof doForgotPassword>) {
  try {
    const response: InferAsyncResponse<ReturnType<typeof forgotPassword>> =
      yield call(forgotPassword, action.email);

    if (response) {
      yield put(
        doCreateAlert({
          active: true,
          message: response.message,
          type: response.status === "FAILURE" ? "DANGER" : "SUCCESS",
        })
      );
      yield put(doForgotPasswordSuccess(response));
    }
  } catch (error) {
    () => noop;
  }
}

function* workLoadChangePassword(action: ReturnType<typeof doChangePassowrd>) {
  try {
    const response: InferAsyncResponse<ReturnType<typeof resetPassword>> =
      yield call(resetPassword, action.request);
    if (response) {
      yield put(
        doCreateAlert({
          active: true,
          message: response.message,
          type: response.status === "FAILURE" ? "DANGER" : "SUCCESS",
        })
      );

      yield put(doChangePassowrdSuccess(response));
    }
  } catch (error) {
    () => noop;
  }
}

export function* watchUserSagas() {
  yield takeEvery(actionTypes.REGISTER_USER, workLoadCreateUser);
  yield takeEvery(actionTypes.LOGIN_USER, workLoadLoginUser);
  yield takeEvery(actionTypes.FORGOT_PASSWORD, workLoadForgotPassword);
  yield takeEvery(actionTypes.CHANGE_PASSWORD, workLoadChangePassword);
  yield takeEvery(actionTypes.GET_USER, workLoadFetchUser);
}
